const SNAPSHOT_TEXT_FIELDS = [
    'appName',
    'prayer',
    'time',
    'remaining',
    'scheduleTitle',
    'open',
    'visibility',
    'reminders',
    'quit',
    'close',
    'automatic',
    'manual',
    'dragHint',
];
function isRecord(value) {
    return typeof value === 'object' && value !== null;
}
function isScheduleRow(row) {
    return (isRecord(row) &&
        typeof row.key === 'string' &&
        typeof row.name === 'string' &&
        typeof row.time === 'string' &&
        typeof row.next === 'boolean');
}
function isSnapshot(value) {
    return (isRecord(value) &&
        typeof value.hidden === 'boolean' &&
        typeof value.remindersPaused === 'boolean' &&
        SNAPSHOT_TEXT_FIELDS.every((field) => typeof value[field] === 'string') &&
        Array.isArray(value.schedule) &&
        value.schedule.every(isScheduleRow));
}
export function parsePrayerSnapshot(value) {
    if (typeof value !== 'string')
        return null;
    try {
        const snapshot = JSON.parse(value);
        if (!isSnapshot(snapshot))
            return null;
        const palette = snapshot.palette;
        if (palette !== undefined &&
            !(isRecord(palette) &&
                ['surface', 'text', 'border', 'highlight', 'accent'].every((key) => typeof palette[key] === 'string' && /^#[0-9a-f]{6}$/i.test(palette[key]))))
            delete snapshot.palette;
        return snapshot;
    }
    catch {
        return null;
    }
}
export const POSITIONS = ['left', 'center', 'right'];
export function parsePosition(saved) {
    const position = saved.trim();
    return POSITIONS.find((candidate) => candidate === position) ?? null;
}
export function positionAt(center, monitorX, monitorWidth) {
    const section = Math.floor((3 * (center - monitorX)) / monitorWidth);
    return POSITIONS[Math.max(0, Math.min(POSITIONS.length - 1, section))];
}
